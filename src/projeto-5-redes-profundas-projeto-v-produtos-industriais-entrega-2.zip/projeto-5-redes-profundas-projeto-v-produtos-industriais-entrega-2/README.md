# Nome do projeto

Escreva um ou dois parágrafos resumindo o objetivo do seu projeto. Lembrando que o objeto é desenvolver um sistema inteligente. Você deve mencionar o produto que está sendo desenvolvido, e não o que se espera obter com este produto.

## Integrantes

* Nome completo do aluno 1
* Nome completo do aluno 2
* Nome completo do aluno 3
* Nome completo do aluno 4

## Professor

* Nome completo do professor (Prof. Hugo Bastos de Paula)

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.

## Histórico de versões

* 0.1.1
    * CHANGE: Atualização das documentacoes. Código permaneceu inalterado.
* 0.1.0
    * Indução do primeiro modelo do agente inteligente.
* 0.0.1
    * Trabalhando na preparação dos dados.

