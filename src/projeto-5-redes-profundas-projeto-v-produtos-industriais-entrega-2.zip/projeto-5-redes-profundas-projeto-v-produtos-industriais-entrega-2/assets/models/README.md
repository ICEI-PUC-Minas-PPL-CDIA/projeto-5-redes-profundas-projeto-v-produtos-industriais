# Modelos do sistema

* modelo final 1
* modelo final 2

O código pode estar no formato original da ferramenta utilizada. 
Pode ser um processo do Orange ou um Jupyter Notebook.


